class CreateFaleConoscos < ActiveRecord::Migration
  def change
    create_table :fale_conoscos do |t|
      t.string :nome
      t.string :email
      t.text :mensagem

      t.timestamps null: false
    end
  end
end
