require 'test_helper'

class FaleConoscoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
