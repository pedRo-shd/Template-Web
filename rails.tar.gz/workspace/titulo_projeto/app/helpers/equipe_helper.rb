module EquipeHelper
end
