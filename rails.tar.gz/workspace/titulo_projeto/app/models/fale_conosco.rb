class FaleConosco < ActiveRecord::Base
end
