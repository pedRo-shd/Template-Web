class ServicosController < ApplicationController
  def index
  end
end
