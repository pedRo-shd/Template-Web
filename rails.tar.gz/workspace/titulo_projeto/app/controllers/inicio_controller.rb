class InicioController < ApplicationController
  def index
  end
end
