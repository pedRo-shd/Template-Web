class EquipeController < ApplicationController
  def index
  end
end
