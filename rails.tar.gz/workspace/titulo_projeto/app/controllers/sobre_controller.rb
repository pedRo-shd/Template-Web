class SobreController < ApplicationController
  def index
  end
end
